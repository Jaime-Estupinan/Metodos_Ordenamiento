package diseño;

import java.util.Arrays;

public class orden {

    public static int burbuja(int[] A) {
        int i, j;
        for (i = 0; i < A.length ; i++) {
            for (j = 0; j < A.length - 1; j++) {
                int elemnA = A[j];
                int elemnB = A[j+1];
                if (elemnA > elemnB) {
                    A[j]=elemnB;
                    A[j+1]=elemnA;
                    
                }
                   }
            System.out.println(Arrays.toString(A));
                }
            
        return 0;
        }
    public static int insercion(int A[]){
        int p, j, aux;
        for (p = 1; p < A.length;p++){
            aux=A[p];
            j=p-1;
            while ((j>=0) && (aux<A[j])){
            A[j+1]=A[j];
            j--;
        }
            A[j+1]=aux;
        }
        System.out.println(Arrays.toString(A));
        return 0;
    }
    public static int seleccion(int A[]){
        int i, j, menor, pos, tmp;
        for(i=0;i<A.length-1;i++){
            menor=A[i];
            pos=i;
            for(j=i+1; j<A.length;j++){
                if(A[j]<menor){
                    menor=A[j];
                    pos=j;
                }
            }
            if(pos!=i){
                tmp=A[i];
                A[i]=A[pos];
                A[pos]=tmp;
            }
        }
        System.out.println(Arrays.toString(A));
        return 0;
    }
  
    

    public static int mergesort(int A[], int izq,int der){
        if(izq<der){
            int m=(izq+der)/2;
            mergesort(A,izq,m);
            mergesort(A,m+1,der);
            merge(A,izq,m,der);
            
        }
        System.out.println(Arrays.toString(A));
        return 0;
    }
  public static int merge(int A[],int izq, int m, int der) {
    int i,j,k;
    int[]B=new int[A.length];
    for(i=izq;i<=der;i++)
        B[i]=A[i];
    i=izq; j=m+1; k=izq;
    while(i<=m && j<=der)
        if(B[i]<=B[j])
            A[k++]=B[i++];
    else
            A[k++]=B[i++];
    while (i<=m)
        A[k++]=B[i++];
        return 0;
    
}
 
}

