package diseño;

import java.util.Arrays;
import java.util.Scanner;

public class Diseño {

    public static void main(String[] args) {
        orden or = new orden();
        Scanner car = new Scanner(System.in);
        int[] Array;
        int op;
        int a = 0;
        int d=0;
        int iz=a-1;
        System.out.println("Digite la cantidad de numeros que quiera organizar");
        a = car.nextInt();
        System.out.println("Su arreglo quedo así: ");
        Array = new int[a];
        for (int x = 0; x < a; x++) {
            Array[x] = (int) (Math.random() * 100) + 1;
        }
            System.out.println(Arrays.toString(Array));
        
        System.out.println("------Menu------");
        System.out.println("1.Burbuja");
        System.out.println("2.Inserccion");
        System.out.println("3.Seleccion");
        System.out.println("4.Merger sort");
        System.out.println("");
        System.out.println("Seleccione el metodo que desee");
        op=car.nextInt();
        switch(op){
            case 1:
                System.out.println("-----------------------------");
        System.out.println("Burbuja");
        System.out.println(orden.burbuja(Array));
        System.out.println("");
             break;
        case 2:
        System.out.println("-----------------------------");
               System.out.println("Insercion");
        System.out.println(orden.insercion(Array));
        System.out.println("");
        break;
        case 3:
        System.out.println("-----------------------------");
               System.out.println("Seleccion");
        System.out.println(orden.seleccion(Array));
        System.out.println("");
        break;
        case 4:
        System.out.println("-----------------------------");
               System.out.println("Mergersort");
        System.out.println(orden.mergesort(Array,d,iz));
            System.out.println("");
            break;
        default:
            System.out.println("Opcion no valida");
        }
    }
}
